from collections import namedtuple

Token = namedtuple('Token', 'name, symbol, address, decimals')
