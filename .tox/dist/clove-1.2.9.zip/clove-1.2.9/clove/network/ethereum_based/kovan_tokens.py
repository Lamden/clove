from clove.network.ethereum_based import Token

kovan_tokens = (
    Token('BlockbustersTest', 'BBT', '0x53E546387A0d054e7FF127923254c0a679DA6DBf', 18),
    Token('PrettyGoodToken', 'PGT', '0x2c76B98079Bb5520FF4BDBC1bf5012AC3E87ddF6', 18),
)
